//
//  eval.cpp
//  Hw2-Maze
//
//  Created by Adil Sultan on 7/15/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Evaluates a boolean expression
//   If infix is a syntactically valid infix boolean expression,
//   then set postfix to the postfix form of that expression, set
//   result to the value of the expression, and return zero.  If
//   infix is not a syntactically valid expression, return 1; in
//   that case, postfix may or may not be changed, but result must
//   be unchanged.)


/*
 Initialize postfix to empty
Initialize the operator stack to empty
For each character ch in the infix string
Switch (ch)
case operand:
append ch to end of postfix
break
case '(':
push ch onto the operator stack
break
case ')':
// pop stack until matching '('
While stack top is not '('
append the stack top to postfix
pop the stack
pop the stack  // remove the '('
break
case operator:
While the stack is not empty and the stack top is not '('
and precedence of ch <= precedence of stack top
append the stack top to postfix
pop the stack
push ch onto the stack
break
While the stack is not empty
append the stack top to postfix
pop the stack */

int evaluate(string infix, string& postfix, bool& result){
    postfix = "";
    stack<char>operators;
    operators.empty();
    for (int ch = 0; ch < infix.size(); ch++){
        switch (ch) {
            case 'T':
                postfix += 'T';
                break;
            case 'F':
                postfix += 'F';
                break;
            case '(':
                operators.push('(');
            case ')':
                while (operators.top() != '('){
                    
                    operators.pop();
                    postfix += operators.top();
                }
                operators.pop();
                break;
            case '&':
                while(!operators.top() && operators.top() != '(' && (operators.top() == '!' || operators.top() == '&') ){
                    postfix += operators.top();
                    operators.pop();
                }
                operators.push(ch);
                break;
                
            case '!':
                while(!operators.top() && operators.top() != '(' && (operators.top() != '|' || operators.top() != '&') ){
                    postfix += operators.top();
                    operators.pop();
                }
                operators.push(ch);
                break;
            
            case '|':
                while(!operators.top() && operators.top() != '(' && (operators.top() == '!' || operators.top() == '&') ){
                    postfix += operators.top();
                    operators.pop();
                }
                operators.push(ch);
                break;
                
            default:
                break;
        }
    }
    
    stack<bool> operands;
    operands.empty();
   /* Initialize the operand stack to empty
    For each character ch in the postfix string
    if ch is an operand
        push the value that ch represents onto the operand stack
    else // ch is a binary operator
        set operand2 to the top of the operand stack
        pop the stack
        set operand1 to the top of the operand stack
        pop the stack
        apply the operation that ch represents to operand1 and
            operand2, and push the result onto the stack
    When the loop is finished, the operand stack will contain one item,
        the result of evaluating the expression*/
    for (int ch= 0; ch < postfix.size(); ch++){
        if (postfix[ch] == 'T')
            operands.push(true);
        else if (postfix[ch]=='F')
            operands.push(false);
        else {
            char operand2;
            operand2=operands.top();
            operands.pop();
            char operand1;
            operand1=operands.top();
            operands.pop();
            if (postfix[ch] == '|'){
                if (operand1 || operand2)
                    operands.push(true);
                else
                    operands.push(false);
            }
            if (postfix[ch] == '&'){
                if (operand1 && operand2)
                    operands.push(true);
                else
                    operands.push(false);
            }
        }

        
    }
    result = operands.top();
    return 0;
}