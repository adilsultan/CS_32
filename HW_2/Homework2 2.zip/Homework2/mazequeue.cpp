//
//  mazequeue.cpp
//  Hw2-Maze
//
//  Created by Adil Sultan on 7/14/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//
#include <iostream>
#include <string>
#include <queue>
using namespace std;

class Coord
{
public:
    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
    int r() const {
        return m_r;
    }
    int c() const {
        return m_c;
    }
private:
    int m_r;
    int m_c;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec){
    queue<Coord> mazeQueue;
    Coord k(sr,sc);
    Coord endMaze(er,ec);
    mazeQueue.push(k);
    maze[sr][sc]='l';
    int r=sr;
    int c=sc;
    
    while (!mazeQueue.empty()){
        cout << endl;
        k = mazeQueue.front();
        r=k.r();
        c=k.c();
        //k = mazeQueue.front();
        mazeQueue.pop();
        if ( r == er && c == ec){
            return true;
        }
        //If you can move NORTH and haven't encountered that cell yet,
        //then push the coordinate (r-1,c) onto the stack and update
        //maze[r-1][c] to indicate the algorithm has encountered it.
        if ( maze[r-1][c] != 'l' && maze[r-1][c] != 'X' && maze[r-1][c] != '@'){
            Coord n(r-1,c);
            mazeQueue.push(n);
            maze[r-1][c] = 'l';
        }
        
        // If you can move EAST and haven't encountered that cell yet,
        //then push the coordinate (r,c+1) onto the stack and update
        //maze[r][c+1] to indicate the algorithm has encountered it.
        if (maze[r][c+1] != 'l' && maze[r][c+1] != 'X' && maze[r][c+1] != '@'){
            Coord e(r,c+1);
            mazeQueue.push(e);
            maze[r][c+1] = 'l';
            
        }
        // If you can move SOUTH and haven't encountered that cell yet,
        // then push the coordinate (r+1,c) onto the stack and update
        //maze[r+1][c] to indicate the algorithm has encountered it.
        if (maze[r+1][c] != 'l' && maze[r+1][c] != 'X' && maze[r+1][c] != '@'){
            Coord s(r+1,c);
            mazeQueue.push(s);
            maze[r+1][c] = 'l';
            
        }
        
        // If you can move WEST and haven't encountered that cell yet,
        //then push the coordinate (r,c-1) onto the stack and update
        //maze[r][c-1] to indicate the algorithm has encountered it.
        if (maze[r][c-1] != 'l' && maze[r][c-1] != 'X' && maze[r][c-1] != '@'){
            Coord w(r,c-1);
            mazeQueue.push(w);
            maze[r][c-1] = 'l';
        }
        
        
        for (int a = 0; a <= 9; a++)
        {
            for (int b = 0; b <= 9; b++)
                cout << maze[a][b];
            cout << endl;
        }
        
            
        
    }
    
    return false;
}



// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise