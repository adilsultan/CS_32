//
//  mazequeue.h
//  Hw2-Maze
//
//  Created by Adil Sultan on 7/14/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#ifndef __Hw2_Maze__mazequeue__
#define __Hw2_Maze__mazequeue__

#include <stdio.h>

#endif /* defined(__Hw2_Maze__mazequeue__) */
