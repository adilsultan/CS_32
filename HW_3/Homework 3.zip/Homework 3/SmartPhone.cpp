//
//  SmartPhone.cpp
//  Homework3
//
//  Created by Adil Sultan on 7/21/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//


#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class SmartPhone{
public:
    SmartPhone(string n);
    virtual ~SmartPhone();
    string name() const;
    virtual string printWebBrowser()const;
    virtual string futureMove()const;
private:
    string m_name;
    string m_browser;
};


class Windows:public SmartPhone{
public:
    Windows(string n);
    virtual ~Windows();
    virtual string printWebBrowser() const;
    virtual string futureMove() const;
    
    
private:
    string m_name;
    string m_browser;
};

class iOS: public SmartPhone{
public:
    iOS(string n, string webBrowserVersionNumber);
    virtual ~iOS();
    virtual string printWebBrowser()const;
    virtual string futureMove() const;
    
private:
    string versionNumber;
    string m_name;
    //string m_browser;
};

class Android:public SmartPhone{
public:
    Android(string n);
    virtual ~Android();
    virtual string printWebBrowser()const;
    virtual string futureMove() const;
    
private:
    string m_name;
   // string m_browser;
};

//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////SmartPhone Implementations///////////////////////////
//////////////////////////////////////////////////////////////////////////////////

SmartPhone::SmartPhone(string n){
    m_name=n;
}

SmartPhone::~SmartPhone(){
    
}

string SmartPhone::printWebBrowser() const{
    return 0;
}

string SmartPhone::futureMove() const{
    return 0;
}

string SmartPhone::name() const{
    return m_name;
}

//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////Windows Implementations///////////////////////////
//////////////////////////////////////////////////////////////////////////////////




Windows:: Windows(string n): SmartPhone(n){
    m_name=n;
}



string Windows::printWebBrowser() const{
    
    return "IE";
}

string Windows::futureMove() const{
    
    return "tries to maintain market share";
}

Windows::~Windows(){
    cout << "Destorying " << name() << " the Windows" << endl;
}

//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////iOS Implementations///////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
iOS::iOS(string n, string webBrowserVerionNumber): SmartPhone(n){
    
    m_name = n;
    versionNumber=webBrowserVerionNumber;
}

iOS::~iOS(){
    cout << "Destroying " << name() << " the iOS" << endl;;
}

string iOS::printWebBrowser()const{

    return "Safari version ";
    return versionNumber;
}

string iOS::futureMove() const{
    return "continues to lose market share";
}

//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////Android Implementations///////////////////////////
//////////////////////////////////////////////////////////////////////////////////
Android::Android(string n):SmartPhone(n){
    m_name=n;
}

Android::~Android(){
    cout << "Detroying " << name() << " the Android" << endl;;
}

string Android::printWebBrowser() const{
    
    return "Chrome";
}

string Android::futureMove() const{
    return "tries to gain market share";
}




void availability(const SmartPhone* cp)
{
    cout << cp->name() << ", using ";
    cout << cp->printWebBrowser();
    cout << ", " << cp->futureMove() << "." << endl;
}


int main()
{
    SmartPhone* phones[4];
    phones[0] = new Windows("Nokia Lumia 521");
    // iOS has a name and initial version number for the Safari Browser
    phones[1] = new iOS("iPhone 6", "5.1.7");
    phones[2] = new Android("Samsung Galaxy S5");
    phones[3] = new Android("Sony Xperia Z1S");
    
    cout << "The SmartPhones availability!" << endl;
    for (int k = 0; k < 4; k++)
        availability(phones[k]);
    
    // Clean up the SmartPhones before exiting
    cout << "Cleaning up" << endl;
    for (int k = 0; k < 4; k++)
        delete phones[k];
}


/*
 The SmartPhones availability!
 Nokia Lumia 521, using IE, tries to maintain its market share.
 iPhone 6, using Safari version 5.1.7, continues to lose market share.
 Samsung Galaxy S5, using Chrome, tries to gain market share.
 Sony Xperia Z1S, using Chrome, tries to gain market share.
 Cleaning up
 Destroying Nokia Lumia 521 the Windows
 Destroying iPhone 6 the iOS
 Destroying Samsung Galaxy S5 the Android
 Destroying Sony Xperia Z1S the Android
 
 So the windows phone takes in the name, and then ==> returns name "using, " return printWebBrowser return "tries to maintain its market share"
 
 The iphone takes in the name and safari version number and cout << "using
 */