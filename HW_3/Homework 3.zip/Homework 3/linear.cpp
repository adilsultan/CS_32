//
//  linear.cpp
//  Hw3_Part2
//
//  Created by Adil Sultan on 7/22/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#include <iostream>
#include <string>
#include <cctype>
using namespace std;


// Return true if any of the chars in the array is lowercase, false
// otherwise.
bool anyLowercase(const char a[], int n)
{
    if (islower(a[0]))
        return true;
    anyLowercase(a+1, n-1);
    
    return false;
}

// Return the number of lowercase chars in the array.
int countLowercase(const char a[], int n)
{
    int lowerCaseCounter = 0;
    if (islower(a[0]))
        lowerCaseCounter++;
    if (islower(a[n]))
        lowerCaseCounter++;
    anyLowercase(a+1, n-1);
    
    return lowerCaseCounter;
}

// Return the subscript of the first lowercase char in the array.
// If no element is lowercase, return -1.
int firstLowercase(const char a[], int n)
{
    if ( islower(a[0]))
        return 0;
    firstLowercase(a+1, n-1);
    return -1;
}

// Return the subscript of the least char in the array (i.e.,
// the smallest subscript m such that there is no k for which
// a[k] < a[m].)  If the array has no elements to examine, return -1.
int indexOfLeast(const char a[], int n)
{
    if (n ==0)
        return -1;
    if ( n == 1)
        return 0;
    if (a[0] <= a[n-1])
        return indexOfLeast(a, n-1);
    return indexOfLeast(a, n-1);
                 
}


int main() {
    
}