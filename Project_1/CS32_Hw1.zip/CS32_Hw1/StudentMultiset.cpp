//
//  StudentMultiset.cpp
//  CS32_Proj2
//
//  Created by Adil Sultan on 7/2/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//
#include <iostream>
#include "StudentMultiset.h"
#include "Multiset.h"

StudentMultiset::StudentMultiset(){}

    
bool StudentMultiset::add(unsigned long id){

    if (student.insert(id))
        return true;
    else
        return false;
}
    //Add a student id to the StudentMultiset.  Return true if and only
    // if the id was actually added.
    
int StudentMultiset::size() const{
    return student.size();
}
    // Return the number of items in the StudentMultiset.  If an id was
    // added n times, it contributes n to the size.
    
void StudentMultiset::print() const{
    
    for (int k = 0; k < student.size(); k++){
        unsigned long j;
        std::cout << student.get(k,j);
    }
    
}
    // Print to cout every student id in the StudentMultiset one per line;
    // print as many lines for each id as it occurs in the StudentMultiset.
    
