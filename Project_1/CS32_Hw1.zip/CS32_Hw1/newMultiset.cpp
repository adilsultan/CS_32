
//
//  Multiset.cpp
//  CS32_Proj2
//
//  Created by Adil Sultan on 7/2/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#include <iostream>
using namespace std;
#include "newMultiset.h"
//#include "Multiset.h"

Multiset::Multiset(){
    multiset_array[DEFAULT_MAX_ITEMS].OtherThing=0;

}

Multiset::Multiset(int max): uniqueCounter(0), limit(max){
 
   multiset_array[DEFAULT_MAX_ITEMS].OtherThing = new ItemType[DEFAULT_MAX_ITEMS];
    //multiset_array[DEFAULT_MAX_ITEMS];
}    // Create an empty multiset.

Multiset::Multiset(const Multiset &OldMultiset): limit(OldMultiset.limit), uniqueCounter(OldMultiset.uniqueCounter){

    multiset_array[DEFAULT_MAX_ITEMS].OtherThing = new ItemType[limit];
    for ( int k = 0; k < limit; k++){
        multiset_array[DEFAULT_MAX_ITEMS].OtherThing = OldMultiset.multiset_array[k].OtherThing;
    }
}


bool Multiset::empty()const{
    if (multiset_array[0].count == 0)
        return true;
    else
        return false;
}// Return true if the multiset is empty, otherwise false.



int Multiset::size()const
{
    int k =0;
    while (multiset_array[k].count <= 0){
        k++;
    }
    
    return k;
}
// Return the number of items in the multiset.  For example, the size
// of a multiset containing "cumin", "cumin", "cumin", "turmeric" is 4.

int Multiset::uniqueSize()const
{
    
    if ( size() > 0){
        double unique_count = 1;
        int j= 0;
        for (int p =1; p <=size(); p++)
        {
            if (multiset_array[j].count != multiset_array[p].count)
                unique_count++;
            else
                continue;
        }
        
        return unique_count;
    }
    else
        
        return 0;
}

// Return the number of distinct items in the multiset.  For example,
// the uniqueSize of a multiset containing "cumin", "cumin", "cumin",
// "turmeric" is 2.

bool Multiset::insert(const ItemType& value){
 for (int k = 0; k <= size(); k++){
        if (!contains(value) && (multiset_array[k].count < limit)){
            *(multiset_array[k].OtherThing) = value;

            return true;
        }
    }
    return false;
    
    return true;
}
// Insert value into the multiset.  Return true if the value was
// actually inserted.  Return false if the value was not insert
// (perhaps because the multiset has a fixed capacity and is full).

int Multiset::erase(const ItemType& value){
    int instance = 0;
    for ( int k = 0; k < size(); k++){
        if ( *(multiset_array[k].OtherThing) == value){
            for ( int j = 0; j < size(); j++){
                multiset_array[j].OtherThing=multiset_array[j+1].OtherThing;
                multiset_array[j].count--;
                instance ++;
                
            }
            return 1;
        }
        
    }
    return 0;
}
// Remove one instance of value from the multiset if present.
// Return the number of instances removed, which will be 1 or 0.

int Multiset::eraseAll(const ItemType& value)
{
    /*int eraseAllCounter = 0;
    for (int x =0; x<size(); x++)
        if (multiset_array[x].SomeThing == value){
            multiset_array[x].SomeThing = multiset_array[x+1].SomeThing;
            eraseAllCounter++;
            multiset_array[x].count--;
        }
    return eraseAllCounter;*/
    
    return -9999;
}
// Remove all instances of value from the multiset if present.
// Return the number of instances removed.

bool Multiset::contains(const ItemType& value)const
{
    for (int k = 0; k < size(); k++)
    {
        if (*(multiset_array[k].OtherThing) == value)
            return true;
    }
    return false;
}
// Return true if the value is in the multiset, otherwise false.

int Multiset::count(const ItemType& value) const{
    /*int valueCounter = 0;
    for ( int k = 0; k < size(); k++){
        if (multiset_array[k].SomeThing == value)
            valueCounter++;
    }
    return valueCounter;*/
    return -99999;
}
// Return the number of instances of value in the multiset.

int Multiset::get(int i, ItemType& value)const{
   /* if (0 <=i || i < uniqueSize()){
        value =multiset_array[i].SomeThing;
        return count(value);
    }
    else*/
        return 0;
}
// If 0 <= i < uniqueSize(), copy into value an item in the
// multiset and return the number of instances of that item in
// the multiset.  Otherwise, leave value unchanged and return 0.
// (See below for details about this function.)

bool Multiset::getMostFrequentValue(ItemType &value) const{
    /*int frequency = 1;
    int y = 0;
    for (int x = 1; x < size(); x++){
        if (multiset_array[y].SomeThing == multiset_array[x+y].SomeThing){
            frequency++;
            value = multiset_array[y].SomeThing;
        }
        else
            y=x;
        continue;
    }
    if (frequency == 1)
        return false;
    else
        */return 0;
}
// If there exists a single item that has the largest number of instances in the multiset,
// then copy into value that item in the multiset and return true.
// However, if there exist more than 1 item that have the largest number of instances in the multiset,
// then do not copy into value any item in the multiset and return false. In other words, value should remain unchanged.
//f there's no item in the multiset, return false.
bool Multiset::getLargestValue(ItemType &value)const{
    /*int temp= 0;
    value = temp;
    for ( int k = 0; k < DEFAULT_MAX_ITEMS; k++){
        if (multiset_array[k].SomeThing > value)
            value = multiset_array[k].SomeThing;
        else
            continue;
        
    }*/
    return -11;
}
// If there exists a value that is the largest value among all the values in the multiset,
// then copy into value that item in the multiset and return true
// Otherwise, return false.
// For both unsigned long and string data type, the higher value can be found by using greater than operator (>).
// For example, 100 is greater than 20, so 100 > 20 is true.
// "ZOO" is greater than "ABC", so "ZOO" > "ABC" is true.

bool Multiset::getSecondLargestValue(ItemType &value) const{
    
    /*int temp= 0;
    value = temp;
    for ( int k = 0; k < DEFAULT_MAX_ITEMS; k++){
        if (multiset_array[k].SomeThing > value)
            value = multiset_array[k].SomeThing;
        else
            continue;
        
    }
    return true;*/
    return 0;
}
// Similar to getLargestValue(), but this time you need to find the second largest value.
// If there exists a value that is the 2nd largest value among all the values in the multiset,
// then copy into value that item in the multiset and return true.
// Otherwise, return false.
// Please note that you cannot use any sorting algorithm to sort the multiset.

bool Multiset::replace(ItemType original, ItemType new_value){
   /* for (int k = 0; k < DEFAULT_MAX_ITEMS; k++){
        if (multiset_array[k].SomeThing == original){
            multiset_array[k].SomeThing = new_value;
            return true;
        }
    }
    */
    return -11;
}
// Replace the item that has the value equal to original by the new value new_value.
// For example, replace("ABC","XYZ") will search the multiset for the item "ABC" and replace all occurrences of "ABC" as "XYZ".
// If the replacement is successful, then return true.
// If there is no item to be replaced, then return false.

int Multiset::countIf(char op, ItemType value) const{
    /*int count_greater = 0;
    int count_less = 0;
    int count_equal = 0;
    switch (op) {
        case '>':
            for ( int k = 0; k < DEFAULT_MAX_ITEMS; k++){
                if (multiset_array[k].SomeThing > value)
                    count_greater++;
            }
            break;
        case '<':
            for ( int j = 0; j<DEFAULT_MAX_ITEMS; j++){
                if (multiset_array[j].SomeThing < value)
                    count_less++;
            }
        case '=':
            for (int i = 0; i < DEFAULT_MAX_ITEMS; i++){
                if (multiset_array[i].SomeThing == value)
                    count_equal++;
            }
            
            
        default: return -1;
            break;
    }
    return count_equal;
    return count_less;
    return count_greater;
    
    */
    return -10;
}
// Count the number of items that the item is greater than, less than, or equal to value.
// For example:
// countIf('>',100) returns the number of items in multiset in which the item is greater than 100.
// countIf('=',"ABC") returns the number of items in multiset in which the item is equal to "ABC".
// countIf('<',50) returns the number of items in multiset in which the item is less than 50.
// If op is a character other than '>','=', and '<', then return -1.

void Multiset::swap(Multiset& other){
   /* Stuff temp[DEFAULT_MAX_ITEMS];
    
    for (int k = 0; k < DEFAULT_MAX_ITEMS; k++){
        temp[k].SomeThing=multiset_array[k].SomeThing;
        multiset_array[k].SomeThing = other.multiset_array[k].SomeThing;
        other.multiset_array[k].SomeThing=temp[k].SomeThing;
        
    }
   */
}
// Exchange the contents of this multiset with the other one.

void Multiset::copyIntoOtherMultiset(Multiset &other){

    
}
// Insert all the items into the multiset in other.


