//
//  testnewMultiset.cpp
//  CS32_Proj2
//
//  Created by Adil Sultan on 7/3/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "newMultiset.h"
#include "newMultiset.cpp"


using namespace std;

int main(){
    
}