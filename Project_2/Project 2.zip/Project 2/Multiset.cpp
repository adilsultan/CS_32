//
//  Multiset.cpp
//  CS32_Project2
//
//  Created by Adil Sultan on 7/7/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//


// check if delete in deconstructor is working properly.

#include "Multiset.h"
#include <iostream>
#include <string>
#include <cassert>
using namespace std;




Multiset::Multiset(){
    m_head=NULL;
}    // Create an empty multiset.

Multiset::Multiset(const Multiset& CopyConstructor){
    node*temp=new node;
    while (temp != NULL && temp->next != NULL){
        temp->next = CopyConstructor.m_head->next;
        temp= temp->next;
    }
    
}//copy constructor

Multiset& Multiset::operator=(const Multiset& rhs){
    if (this != &rhs){
        Multiset temp(rhs);
        swap(temp);
    }
    return *this;
}

Multiset::~Multiset(){
    node* deconstruct = m_head;
    while (deconstruct != NULL){
        m_head->next=deconstruct->next;
        delete deconstruct;
        deconstruct=m_head->next;
        deconstruct = deconstruct->next;
        
    }
}//destructor

bool Multiset::empty()const{
    if (m_head==NULL)
        return true;
    else
        return false;
}   // Return true if the multiset is empty, otherwise false.

int Multiset::size()const{
    node*temp;
    temp=m_head;
    int m_size = 0;
    while (temp!= NULL){
        m_size++;
        temp=temp->next;
    }
    return m_size;
}
// Return the number of items in the multiset.  For example, the size
// of a multiset containing "cumin", "cumin", "cumin", "turmeric" is 4.

int Multiset::uniqueSize()const{

    return uCount;
}
// Return the number of distinct items in the multiset.  For example,
// the uniqueSize of a multiset containing "cumin", "cumin", "cumin",
// "turmeric" is 2.

bool Multiset::insert(const std::string& value){
    if (!contains(value))
        uCount++;
    node*latest=new node; // add new node to the top of the list
    latest->type = value;
    latest->next = m_head;
    m_head=latest;
    m_head->count++;
    return true;
}
// Insert value into the multiset.  Return true if the value was
// actually inserted.  Return false if the value was not inserted
// (perhaps because the multiset has a fixed capacity and is full).

int Multiset::erase(const std::string& value){

    node*current = m_head; //create a temp node called current
    while (current !=NULL /*&& current->next !=NULL*/){ //traverse the list
        if ( current->next != NULL && (current->next->type==value)) //if next is != NULL
            break; //and contains value then break out of this loop.
        else
            current = current->next; //otherwise continue through thr list
    }
    if ( current != NULL){
        node*target=current->next; //delete the node with value.
        current->next=target->next;
        delete target;
        
        return 1; //return 1 if the node is deleted
    }
    
    return 0; //if reaching this point that means the list was traversed and value is not in the list.
}
// Remove one instance of value from the multiset if present.
// Return the number of instances removed, which will be 1 or 0.

int Multiset::eraseAll(const std::string& value){
    int eraseCounter = 0;
    
    if (!contains(value)) // if the multiset doesn't contain the value return false.
        return false;
    if (contains(value)){ // if the multiset contains the value
        node*current = m_head; //create a temp node
        while (current !=NULL){ //traverse the list
            if ( current->next != NULL && current->next->type == value){//
                node*target=current->next; //delete that instance
                current->next=target->next;
                delete target;
                eraseCounter++; //increment the counter of instances erased
            }
            current=current->next; // continue through the loop
        }
      
    }
    
    return eraseCounter;
}
// Remove all instances of value from the multiset if present.
// Return the number of instances removed.

bool Multiset::contains(const std::string& value)const{
    node*temp; // create a temp node
    temp = m_head;
    while ( temp != NULL && temp->next != NULL){ //traverse the node
        if (temp->next->type==value) //if next is equal to value
            return true;
        else
            temp = temp->next; //otherwise continue to traverse until reaching node
    }
    return false; //return false if value isn't in the Multiset
}
// Return true if the value is in the multiset, otherwise false.

int Multiset::count(const std::string& value)const{
    int instanceCounter = 0;
    node *temp;
    temp = m_head;
    while (temp!= NULL){
        if(temp != NULL && temp->type == value){
        instanceCounter++;
        }
        temp=temp->next;
    }
    
    return instanceCounter;
}
// Return the number of instances of value in the multiset.

int Multiset::get(int i, std::string& value)const{
    if ( 0<= i < uniqueSize()){
        node*temp = m_head;
        for (int a = 0; a <= i; a++){
            temp=temp->next;
            value = temp->type;
        }
        return count(value);
    }
    else
        return 0;
}
// If 0 <= i < uniqueSize(), copy into value an item in the
// multiset and return the number of instances of that item in
// the multiset.  Otherwise, leave value unchanged and return 0.
// (See below for details about this function.)

bool Multiset::getMostFrequentValue(ItemType &value)const{
    Multiset dummy = *this;
    int m_mostfrequent = 0;
    node*temp = NULL;
    while (!dummy.empty()){
        while (temp != NULL && temp->next != NULL){
            //dummy.count(temp->type);
            if ( dummy.count(temp->type) != 1){
                m_mostfrequent = dummy.count(temp->type);
            dummy.eraseAll(temp->type);
            temp=temp->next;
            }
        }
    }
    return m_mostfrequent;
    return false;
}
// If there exists a single item that has the largest number of instances in the multiset,
// then copy into value that item in the multiset and return true.
// However, if there exist more than 1 item that have the largest number of instances in the multiset,
// then do not copy into value any item in the multiset and return false. In other words, value should remain unchanged.
// If there's no item in the multiset, return false.

bool Multiset::getLargestValue(ItemType &value)const{
    node*temp;
    while(temp != NULL && temp->next != NULL){

        }
        return true;
    
    return false;
}
// If there exists a value that is the largest value among all the values in the multiset,
// then copy into value that item in the multiset and return true
// Otherwise, return false.
// For both unsigned long and string data type, the higher value can be found by using greater than operator (>).
// For example, 100 is greater than 20, so 100 > 20 is true.
// "ZOO" is greater than "ABC", so "ZOO" > "ABC" is true.

bool Multiset::getSecondLargestValue(ItemType &value)const{
    node*temp;
    while(temp != NULL && temp->next != NULL){
        for ( int a = 0; a < size(); a++){

        }
        return true;
    }
    return false;
}
// Similar to getLargestValue(), but this time you need to find the second largest value.
// If there exists a value that is the 2nd largest value among all the values in the multiset,
// then copy into value that item in the multiset and return true.
// Otherwise, return false.
// Please note that you cannot use any sorting algorithm to sort the multiset.

bool Multiset::replace(ItemType original, ItemType new_value){
    node*current;
    current = m_head;
    if (current == NULL || current->next == NULL)
        return false;
    while (current != NULL){
        if ( current != NULL && current->type == original){
            current->type = new_value;
            current = current->next;
        }
    }
    return true;
}
// Replace the item that has the value equal to original by the new value new_value.
// For example, replace("ABC","XYZ") will search the multiset for the item "ABC" and replace all occurrences of "ABC" as "XYZ".
// If the replacement is successful, then return true.
// If there is no item to be replaced, then return false.

int Multiset::countIf(char op, ItemType value)const{
    int occurence=0;
    node*temp;
    if ( op == '>'|| op == '<' || op == '='){
        while ( temp != NULL){
            if (temp->next->type == value)
                occurence++;
        }
        return occurence;
    }
    else
        return -1;
    
    
}
// Count the number of items that the item is greater than, less than, or equal to value.
// For example:
// countIf('>',100) returns the number of items in multiset in which the item is greater than 100.
// countIf('=',"ABC") returns the number of items in multiset in which the item is equal to "ABC".
// countIf('<',50) returns the number of items in multiset in which the item is less than 50.
// If op is a character other than '>','=', and '<', then return -1.

void Multiset::swap(Multiset& other){
    node*temp=m_head;
    while ( temp != NULL && temp->next != NULL){
        temp->next=other.m_head->next;
        temp=temp->next;
    }
}
// Exchange the contents of this multiset with the other one.

void Multiset::copyIntoOtherMultiset(Multiset &other)const{
    node*temp;
    while ( temp != NULL && temp-> next != NULL){
        other.insert(temp->type);
    }
}
// Insert all the items into the multiset in other.


void combine (const Multiset &ms1, const Multiset& ms2, Multiset& result){
    ms1.copyIntoOtherMultiset(result);
    ms2.copyIntoOtherMultiset(result);
    
}

void subtract(const Multiset& ms1, const Multiset& ms2, Multiset& result){
    int x;
    ItemType temporaryValue;
    ms1.get(x, temporaryValue);
    ms2.get(x, temporaryValue);
    
    
}

