#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>
#include <string>
using namespace std;

Actor* Player::getActor(int col, int row){
    return getWorld()->checkActorLocation(col, row);
}

bool health_Actor::getPosition(int col, int row){
    Actor* ap = getActor(col, row);
    if ( ap != NULL){
        if(ap->getID() == IID_WALL)
            return false;
    }
    return true;
}

void Player::doSomething(){
    if (!isAlive()){
        return;
    }
    Direction move = Player::getDirection();
    int ch;
        if (getWorld()->getKey(ch))
        {
            // user hit a key this tick!
            switch (ch)
            {
                case KEY_PRESS_LEFT:
                    //move player to the left
                    if (!getPosition(getX()-1, getY())){
                        if ( move != left){
                            setDirection(left);
                        }
                        break;
                    }
                    
                    if (move == left && getX() > 0){
                        Player::moveTo(getX()-1,getY());
                    }
                    
                    else{
                        if (getX() >0) {
                            setDirection(left);
                            Player::moveTo(getX()-1, getY());
                        }
                    }
                    break;
                case KEY_PRESS_RIGHT:
                    //move player to the right
                    if (!getPosition(getX()+1, getY())){
                        if ( move != right){
                            setDirection(right);
                        }
                        break;
                    }
                    
                    if (move == right && getX() > 0){
                        Player::moveTo(getX()+1,getY());
                    }
                    
                    else{
                        if (getX() >0) {
                            setDirection(right);
                            Player::moveTo(getX()+1, getY());
                        }
                    }
                    break;
                case KEY_PRESS_DOWN:
                    //move player down
                    if (!getPosition(getX(), getY()-1)){
                        if ( move != down){
                            setDirection(down);
                        }
                        break;
                    }
                    
                    if (move == down && getX() > 0){
                        Player::moveTo(getX(),getY()-1);
                    }
                    
                    else{
                        if (getX() >0) {
                            setDirection(down);
                            Player::moveTo(getX(), getY()-1);
                        }
                    }
                    break;
                case KEY_PRESS_UP:
                    // move player up
                    if (!getPosition(getX(), getY()+1)){
                        if ( move != up){
                            setDirection(up);
                        }
                        break;
                    }
                    
                    if (move == up && getX() > 0){
                        Player::moveTo(getX(),getY()+1);
                    }
                    
                    else{
                        if (getX() >0) {
                            setDirection(up);
                            Player::moveTo(getX(), getY()+1);
                        }
                    }
                    break;
                //case KEY_PRESS_SPACE:
                    //add a Bullet in the square in front of the Player
                  //  break;
                    // etc... }
            }
        }
    
    //move() shit here
}

