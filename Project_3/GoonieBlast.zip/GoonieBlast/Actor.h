#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"
#include "GameConstants.h"
#include <iostream>
#include <string>

class GameWorld;

class Actor: public GraphObject{
public:
    Actor(int imageID, int startX, int startY, Direction dir = none, int sub_level = 0, StudentWorld* game = nullptr): GraphObject(imageID, startX, startY,dir, sub_level){
        
        setVisible(true);
        world=game;
    }
    virtual StudentWorld* getWorld(){
        return world; 
    }
    virtual void doSomething() = 0;
    virtual bool isAlive(){
        return true;
    }
    virtual ~Actor(){
        
    }
private:
    StudentWorld*world;
};




class wall: public Actor {
public:

    wall(int imageID, int startX, int startY, Direction dir=none, int sub_level = 0): Actor(6, startX, startY, none,sub_level){
        setVisible(true);
    }
    void doSomething(){
        
    }
    virtual ~wall(){
        
    }
private:
    
};

class health_Actor: public Actor{
public:
    health_Actor(int imageID, int startX, int startY, Direction dir=none, int sub_level = 0, StudentWorld* game = nullptr): Actor(imageID, startX, startY, none,sub_level, game){
        //setVisible(true);
        currentHealth = 0;
        ammo = 0;
    }
    
    virtual void incrementHealth(int m_health){
        currentHealth += m_health;
    }
    virtual void decrementHealth(int m_health){
        currentHealth -= m_health;
    }
    
    virtual int get_health(int m_health){
        return currentHealth;
    }
    
    virtual bool isAlive(){
        return (currentHealth != 0);
    }
    
    virtual Actor* getActor(int col, int row) = 0;
    
    virtual bool getPosition(int col, int row);
    
    virtual ~health_Actor(){
        
    }
private:
    int currentHealth;
    int ammo;
    
};

class Player:public health_Actor{
public:
    Player(int imageID, int startX, int startY, Direction dir=none, int sub_level = 0, StudentWorld* game = nullptr): health_Actor(0, startX, startY, none,sub_level, game){
        
        setVisible(true);
        incrementHealth(20);
        livesCounter = 3;
        
    }
    
    int getLives(){
        return livesCounter;
    }
    
    void incrementLives(){
        livesCounter++;
    }
    
    void decrementLives(){
        livesCounter--;
    }
    
    virtual void doSomething();
    
    virtual Actor* getActor (int col, int row);
    
    virtual ~Player(){
        
    }
    
private:
    int livesCounter;
};







/*
class Robot:public Actor{
public:
    Robot();
    virtual ~Robot();
    
private:
    
    
};

class Items: public Actor{
public:
    Items();
    virtual ~Items();
    
    
private:
    
};


class Bullet:public Items{
public:
    Bullet();
    ~Bullet();
    
    
private:
    
    
};


class Snarlbots: public health_Actor{
    Snarlbots();
    virtual ~Snarlbots();
};

class Kleptobots: public health_Actor{
public:
    Kleptobots();
    virtual ~Kleptobots();
private:
};






class Gate: public Actor{
    Gate();
    virtual ~Gate();
};

class Goodies: public Items{
    Goodies();
    virtual ~Goodies();
};

class Jewels: public Items{
    Jewels();
    virtual ~Jewels();
};

class Hostages:public Items{
    Hostages();
    virtual ~Hostages();
};
*/

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_

