#include "StudentWorld.h"
#include "Actor.h"
#include "Level.h"
#include <string>
using namespace std;

class Actor;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}


// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
void StudentWorld::loadlevel() {
    Level lev(assetDirectory());
    
    Level::LoadResult result = lev.loadLevel("level00.dat");
    if (result == Level::load_fail_file_not_found)
        cerr << "Could not find level00.dat data file\n";
    else if (result == Level::load_fail_bad_format)
            cerr << "Your level was improperly formatted\n";
    else if (result == Level::load_success)
            {
                cerr << "Successfully loaded level\n";
                for (int col = 0; col <VIEW_WIDTH; col++){
                    for (int row = 0; row < VIEW_HEIGHT; row++){
                        Level::MazeEntry itemtype = lev.getContentsOf(col, row, getCurrentSubLevel());
                        switch (itemtype)
                        {
                            case Level::wall:
                                n_Actor= new wall (6, col, row, GraphObject::none, getCurrentSubLevel());
                                actorContainer.push_back(n_Actor);
                                break;
                            case Level::player:
                                n_Actor= new Player(0, col, row, GraphObject:: none, getCurrentSubLevel(), this);
                                actorContainer.push_back(n_Actor);
                                break;
                        }
                    }

                }
            }
}



//Here’s pseudocode for how the move() method might be implemented:
int StudentWorld::move(){
    for (int col = 0; col < VIEW_WIDTH; col++){
        for (int row = 0; row < VIEW_HEIGHT; row++){
            checkActorLocation(col, row);
            if (n_Actor->isAlive())
                n_Actor->doSomething();
        }
    }
return GWSTATUS_CONTINUE_GAME;
}
