#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include <vector>
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)
	{
        std::vector<Actor*> actorContainer;
	}
void loadlevel();
    virtual int init()
	{
        loadlevel();
        return GWSTATUS_CONTINUE_GAME;
	}
    
    
    
    
    virtual int move();

    virtual void cleanUp(){
        
    }
    
    virtual int getCurrentSubLevel()
    {
        return 0;
    }
    
    Actor* getnewActor(){
        return n_Actor;
    }
    Actor* checkActorLocation(int col, int row){
        return 0;
    }
    
    virtual ~StudentWorld(){
        cleanUp();
    }

private:
    
    std::vector<Actor*> actorContainer;
    Actor* n_Actor;
    
    
};

#endif // STUDENTWORLD_H_
