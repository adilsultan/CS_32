//
//  WordLadderSolver.cpp
//  CS32Proj4
//
//  Created by Adil Sultan on 8/9/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//
// WordLadderSolver.cpp

// This is an incomplete, and thus incorrect, implementation of WordLadderSolver
// functionality.  Your job is to change WordLadderSolverImpl to a correct,
// hopefully efficient, implementation.  You can change it any way you like,
// subject to restrictions in the spec (e.g., that the only C++ library
// containers you are allowed to use are vector, list, stack, and queue (and
// string); if you want anything fancier, implement it yourself).

#include "WordLadderSolver.h"
#include <string>
#include <vector>
#include <queue>
#include <cctype>
#include <algorithm>
#include <list>
using namespace std;

void removeNonLetters(string& s);

// This class does the real work of the implementation.


class hashTable{
public:
    hashTable(int size);
    bool insertnode(const string& k);
    bool deletenode(const string& k);
    void deleteAll(const string& k);
    bool search (const string& k);
private:
    vector<list<string>> theList;
    int cSize;
    int tSize;
    int hashFunction(const string& word);
    
};

hashTable::hashTable(int size){
    vector<list<string> >theList(size);
    cSize=0;
    tSize=size;
    
}

bool hashTable::search(const string& k){
    const list<string> & someList = theList[hashFunction(k)];
    return find(someList.begin(), someList.end(),k) != someList.end(); //if you don't reach the end then the word is in the
                                                                        //list so return
}
bool hashTable::insertnode(const string& k){
    int value = hashFunction(k);
    list<string> & m_list= theList[value];
    if (find(m_list.begin(), m_list.end(), k) != m_list.end())
        return false; //didn't insert the node
    m_list.push_back(k);
    cSize++;
    return true; // if node was inserted return true
    
}

void hashTable::deleteAll(const string& k){
    for ( int k = 0; k < theList.size(); k++){
        theList[k].clear();
    }
}


int hashTable::hashFunction(const string&k){ //taken literally from lecture notes
    int i, total=0;
    for ( i=0;i<k.length();i++){
        total = total + (i+1)*k[i];
    }
    total = total % tSize;
    
    return (total);
}




class WordLadderSolverImpl
{
public:
    WordLadderSolverImpl() {}
    ~WordLadderSolverImpl() {}
    void createWordList(hashTable);
    int buildLadder(string start, string end, vector<string>& ladder);
    void insertLetter();
    void deleteLetter();
    void swapLetter();
    void replaceLetter(string start, string end, hashTable);
    
private:
    // You probably want something more sophisticated/efficient than this:
    list<string> m_words;
    queue<string> current;
    queue<string> temp;
};

void WordLadderSolverImpl::createWordList(hashTable)
{
    // You probably want something more sophisticated/efficient than this;
    // for one thing, it's horribly slow on a 60,000 word file.
    
    for (string word : hashTable(int size))
    {
        removeNonLetters(word);
        if ( ! word.empty()  &&  find(m_words.begin(), m_words.end(), word) == m_words.end())
            //m_words.push_back(word);
            insertnode(word);
        
        
    }
}





void WordLadderSolverImpl::replaceLetter(string start, string end, hashTable){
    if (start.size()!= end.size())
        return;
   // queue<string> current;
   // queue<string> next;
    current.push(start);
    while(!current.empty()){
        current.pop();
        if (current.back() == end)
            return;
        
    }
}






int WordLadderSolverImpl::buildLadder(string start, string end, vector<string>& ladder)
{
    ladder.clear();
    removeNonLetters(start);
    if (find(m_words.begin(), m_words.end(), start) == m_words.end())
        return 1;
    removeNonLetters(end);
    if (find(m_words.begin(), m_words.end(), end) == m_words.end())
        return 2;
    if (start == end)
        return 3;
    
    
    
    // This is not always correct, because, of course, sometimes a word ladder
    // *does* exist from the start to the end word; this code makes no attempt
    // to find one.
    return -1;
}





void removeNonLetters(string& s)
{
    string::iterator to = s.begin();
    for (char ch : s)
    {
        if (isalpha(ch))
        {
            *to = tolower(ch);
            to++;
        }
    }
    s.erase(to, s.end());  // chop off everything from "to" to end.
}

//******************** WordLadderSolver functions **********************************

// These functions simply delegate to WordLadderSolverImpl's functions.
// You probably don't want to change any of this code.

WordLadderSolver::WordLadderSolver()
{
    m_impl = new WordLadderSolverImpl;
}

WordLadderSolver::~WordLadderSolver()
{
    delete m_impl;
}

void WordLadderSolver::createWordList(const vector<string>& words)
{
    m_impl->createWordList(words);
}

int WordLadderSolver::buildLadder(string start, string end, vector<string>& ladder)
{
    return m_impl->buildLadder(start, end, ladder);
}
