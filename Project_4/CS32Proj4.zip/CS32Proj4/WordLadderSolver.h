//
//  WordLadderSolver.h
//  CS32Proj4
//
//  Created by Adil Sultan on 8/9/15.
//  Copyright (c) 2015 Adil Sultan. All rights reserved.
//

#ifndef WORDLADDERSOLVER_INCLUDED
#define WORDLADDERSOLVER_INCLUDED

#include <string>
#include <vector>

class WordLadderSolverImpl;

class WordLadderSolver
{
public:
    WordLadderSolver();
    ~WordLadderSolver();
    void createWordList(const std::vector<std::string>& words);
    int buildLadder(std::string start, std::string end, std::vector<std::string>& ladder);
private:
    WordLadderSolverImpl* m_impl;
    // WordLadderSolvers can not be copied or assigned.  We enforce this
    // by declaring the copy constructor and assignment operator private and
    // not implementing them.
    WordLadderSolver(const WordLadderSolver&);
    WordLadderSolver& operator=(const WordLadderSolver&);
};

#endif // WORDLADDERSOLVER_INCLUDED
